# iAVO Deployment

Run `bash launch.sh` or push to GitHub with deploy.yml configured.