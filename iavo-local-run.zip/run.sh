#!/bin/bash
pip install -r requirements.txt
uvicorn app.myai_node:app --reload --port 7777
