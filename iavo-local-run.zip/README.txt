1. Open Terminal
2. Run: bash run.sh
3. Visit http://localhost:7777/docs to use the iAVO API